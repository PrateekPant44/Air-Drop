package com.ammar.sharing.common.utils;

public class TypesUtils {
    public static native int byteArrayToShort(byte[] array);
    public static native long byteArrayToLong(byte[] array);
}
