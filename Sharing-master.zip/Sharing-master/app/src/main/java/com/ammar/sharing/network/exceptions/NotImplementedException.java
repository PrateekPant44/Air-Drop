package com.ammar.sharing.network.exceptions;

public class NotImplementedException extends Exception {
    public NotImplementedException(String message) {
        super(message);
    }
}
